package com.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;


import com.model.Pizza_Menu;

@Repository
public interface Pizza_Repository extends CrudRepository<Pizza_Menu, Long>{
	
}
