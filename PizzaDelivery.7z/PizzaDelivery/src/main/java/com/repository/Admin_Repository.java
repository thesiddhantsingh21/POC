package com.repository;

import org.springframework.data.repository.CrudRepository;

import com.model.NewAdmin;

public interface Admin_Repository extends CrudRepository<NewAdmin, Integer>{
	
}
