package com.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.exception.InvalidInputException;
import com.model.NewAdmin;
import com.model.Pizza_Menu;
import com.model.Pizza_Order;
import com.service.Pizza_Service;


@RestController
@RequestMapping("/landing")
public class Pizza_Controller {
	    @Autowired
	    Pizza_Service pizzaService;
	    
	    @GetMapping("/newAdmin")
	    public String saveAdmin(@RequestParam String username, @RequestParam String firstname, @RequestParam String lastname, @RequestParam Integer age, @RequestParam String password) {
	    	NewAdmin newAdmin = new  NewAdmin(username,firstname,lastname,age,password);
	    	pizzaService.saveAdmin(newAdmin);
	    	return "Admin Created";
	    }

	    @GetMapping("/getPizza")
	    public List<Pizza_Menu> getAllPizza() {
	        return pizzaService.getPizzaMenu();
	    }
	    
	    @PostMapping("/addpizza/{pizzaId}/{pizzaName}/{pizzaPrice}")
	    public Pizza_Menu addPizzaMenu(@PathVariable  Long pizzaId,@PathVariable String pizzaName,@PathVariable int pizzaPrice )  
		{
			return pizzaService.addPizzaMenu(pizzaId,pizzaName,pizzaPrice);	
		}
	    
	    @GetMapping("/getOrderDetails")
	    public List<Pizza_Order> getOrderDetails() {
	        return pizzaService.getOrderDetails();
	    }
	    
	    @PostMapping("/addOrderDetails/{orderId}/{pizzaId}/{customerName}/{customerAddress}/{customerPhoneNo}")
	    public Pizza_Order addPizzaMenu(@PathVariable Long orderId,@PathVariable int pizzaId,@PathVariable String customerName,@PathVariable String customerAddress,@PathVariable String customerPhoneNo )  
		{
			return pizzaService.addPizzaMenu(orderId,pizzaId,customerName,customerAddress,customerPhoneNo);	
		}
	    
	    @GetMapping("/viewOrderDetails/{orderId}")
	    public Optional<Pizza_Order> viewOrderDetail(@PathVariable Long orderId) throws InvalidInputException
	    {
	    	 return pizzaService.viewOrderDetails(orderId);
	    }
}
