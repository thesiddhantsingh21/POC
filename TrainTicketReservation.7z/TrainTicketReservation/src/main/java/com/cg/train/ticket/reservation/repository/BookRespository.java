package com.cg.train.ticket.reservation.repository;

import org.springframework.data.repository.CrudRepository;

import com.cg.train.ticket.reservation.model.Book;

public interface BookRespository extends CrudRepository<Book, Integer> {

}
