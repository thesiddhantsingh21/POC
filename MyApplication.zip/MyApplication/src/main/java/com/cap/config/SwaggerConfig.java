package com.cap.config;


//@Configuration
//@EnableSwagger2
public class SwaggerConfig {
	
	/*
	 * @Bean public Docket applicationapi() { return new
	 * Docket(DocumentationType.SWAGGER_2).select().apis(RequestHandlerSelectors.
	 * basePackage("com.cap.controller")) .paths(regex("/product.*")) .build()
	 * .apiInfo(metaData()); } private ApiInfo metaData() { ApiInfo apiInfo = new
	 * ApiInfo( "Spring Boot REST API", "Spring Boot REST API for Online Store",
	 * "1.0", "Terms of service", new Contact("Siddhant Shekhar",
	 * "https://springframework.guru/about/", "siddhant.shekhar2103@gmail.com"),
	 * "Apache License Version 2.0", "https://www.apache.org/licenses/LICENSE-2.0");
	 * return apiInfo;
	 * 
	 * }
	 */

}
