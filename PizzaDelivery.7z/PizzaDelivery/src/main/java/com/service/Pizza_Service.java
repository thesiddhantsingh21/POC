package com.service;

import java.util.List;
import java.util.Optional;

import com.exception.InvalidInputException;
import com.model.Admin;
import com.model.NewAdmin;
import com.model.Pizza_Menu;
import com.model.Pizza_Order;

public interface Pizza_Service {
	
	public void saveAdmin(NewAdmin newadmin);
	
	public List<Pizza_Menu> getPizzaMenu();

	public Pizza_Menu addPizzaMenu(Long pizzaId, String pizzaName, int pizzaPrice);

	public List<Pizza_Order> getOrderDetails();

	public Pizza_Order addPizzaMenu(Long orderId, int pizzaId, String customerName, String customerAddress,
			String customerPhoneNo);

	public Optional<Pizza_Order> viewOrderDetails(Long orderId) throws InvalidInputException;

	//public Pizza_Menu updateMenu(Long pizzaId, String pizzaName, int pizzaPrice) throws InvalidInputException;
}
