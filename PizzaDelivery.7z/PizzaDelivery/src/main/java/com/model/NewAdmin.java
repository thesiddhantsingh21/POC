package com.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
@Table(name = "users")
public class NewAdmin {
	@Id
	@NotNull
	private String username;
	@NotNull
	private String firstname;
	private String lastname;
	@Min(18)
	@NotNull
	private int age;
	@NotNull
	@Size(min = 6, message = "Password should be a minimum of 6 characters")
	private String password;
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	@Override
	public String toString() {
		return "NewAdmin [username=" + username + ", firstname=" + firstname + ", lastname=" + lastname + ", age=" + age
				+ ", password=" + password + "]";
	}
	public NewAdmin(@NotNull String username, @NotNull String firstname, String lastname, @Min(18) @NotNull int age,
			@NotNull @Size(min = 6, message = "Password should be a minimum of 6 characters") String password) {
		super();
		this.username = username;
		this.firstname = firstname;
		this.lastname = lastname;
		this.age = age;
		this.password = password;
	}
	
	
}
