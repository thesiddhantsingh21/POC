package com.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "pizzas")
public class Pizza_Menu {
	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long pizzaId;
	    private String pizzaName;
	    private int pizzaPrice;
	    public Pizza_Menu() {}
	   
		public Pizza_Menu( String pizzaName, int pizzaPrice) {
			super();
			this.pizzaName = pizzaName;
			this.pizzaPrice = pizzaPrice;
		}

		public Long getPizzaId() {
			return pizzaId;
		}
		
		public void setPizzaId(Long pizzaId) {
			this.pizzaId = pizzaId;
		}
		
		public String getPizzaName() {
			return pizzaName;
		}
		
		public void setPizzaName(String pizzaName) {
			this.pizzaName = pizzaName;
		}
		
		public int getPizzaPrice() {
			return pizzaPrice;
		}
		
		public void setPizzaPrice(int pizzaPrice) {
			this.pizzaPrice = pizzaPrice;
		}

		@Override
		public String toString() {
			return "Pizza_Menu [pizzaId=" + pizzaId + ", pizzaName=" + pizzaName + ", pizzaPrice=" + pizzaPrice + "]";
		}

		
		
		

		

		

}
