package com.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.model.Pizza_Order;

@Repository
public interface Order_Repository extends CrudRepository<Pizza_Order, Long> {

}
